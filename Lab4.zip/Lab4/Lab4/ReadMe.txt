Input: /class/s16419x/lab4/gensort-out-50M
Output: /scr/dsindhu/lab4/output-final
Partition File: /scr/dsindhu/lab4/output-part.lst
 