
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.mapreduce.lib.partition.InputSampler;
import org.apache.hadoop.mapreduce.lib.partition.TotalOrderPartitioner;
import org.apache.hadoop.util.GenericOptionsParser;


public class TotalOrderSorting {
	public static final int NUM_REDUCE_TASKS = 8;
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {
		
		Configuration conf = new Configuration();

		String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
		if (otherArgs.length != 2) {
			System.err.println("Usage: SortTest <in> <out>");
			System.exit(2);
		}
		
		String inputDir = args[0];
		String outputDir = args[1];
		
		//map input path is the same as the input file
		Path mapInputPath = new Path(inputDir);
		// map output path gives the sequence file, input file is converted to
		Path mapOutputPath = new Path(outputDir + "-inter");
		// reduce output path gives the final output file
		Path reduceOutputPath = new Path(outputDir + "-final");
		// define the location of the generated Partition file
		Path partitionPath = new Path(outputDir+"-part.lst");
		
		// First Job: Convert the text file into sequence file <K,V> - Map only Job for sampling
		Job mapJob = Job.getInstance(conf, "Convert to Sequence File");
		mapJob.setJarByClass(TotalOrderSorting.class);

		// Use the mapper implementation with zero reduce tasks
		mapJob.setMapperClass(Sort_Mapper.class);
		mapJob.setNumReduceTasks(0);

		mapJob.setOutputKeyClass(Text.class);
		mapJob.setOutputValueClass(Text.class);
		FileInputFormat.setInputPaths(mapJob, mapInputPath);
		
		// Set the output format to a sequence file 
		mapJob.setOutputFormatClass(SequenceFileOutputFormat.class);
		FileOutputFormat.setOutputPath(mapJob, mapOutputPath);
			
		// Submit the job and get completion code.
		int code = mapJob.waitForCompletion(true) ? 0 : 1;
						
		// Second Job
		if (code == 0) {
			Job reduceJob = Job.getInstance(conf, "Reduce Name");
			reduceJob.setJarByClass(TotalOrderSorting.class);
			
			// Set the input to the previous job's output
			reduceJob.setInputFormatClass(SequenceFileInputFormat.class);
			FileInputFormat.setInputPaths(reduceJob, mapOutputPath);
			
			// Set the output path to the command line parameter
			reduceJob.setOutputFormatClass(TextOutputFormat.class);
			FileOutputFormat.setOutputPath(reduceJob, reduceOutputPath);
						
			// Here, use the identity mapper to output the key/value pairs in
			// the SequenceFile
			reduceJob.setReducerClass(Sort_Reducer.class);

			// Set output key and value types
			reduceJob.setMapOutputKeyClass(Text.class);
			reduceJob.setMapOutputValueClass(Text.class);
			reduceJob.setOutputKeyClass(Text.class);
			reduceJob.setOutputValueClass(NullWritable.class);
			
			// Set the number of reduce tasks to an appropriate number for the
			// amount of data being sorted
			reduceJob.setNumReduceTasks(NUM_REDUCE_TASKS);

			// Use Hadoop's TotalOrderPartitioner class
			reduceJob.setPartitionerClass(TotalOrderPartitioner.class);

			// Set the partition file
			TotalOrderPartitioner.setPartitionFile(reduceJob.getConfiguration(), partitionPath);
			
			// Use the InputSampler to go through the output of the previous
			// job, sample it, and create the partition file
			InputSampler.writePartitionFile(reduceJob, new InputSampler.RandomSampler(0.1, 10000, 10));
			
			// Submit the job
			reduceJob.waitForCompletion(true);
				
	}
		// Cleanup the partition file and the staging directory
		FileSystem.get(new Configuration()).delete(mapOutputPath, true);

		System.exit(code);
}
	
public static class Sort_Mapper extends Mapper<LongWritable, Text, Text, Text> {
		
		private Text outkey = new Text();

		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

			// Parse the input string into a nice map
			String invalue = value.toString();
			if (invalue != null) {
				outkey.set(invalue.substring(0, 10));
				context.write(outkey, value);
			}
		}
	}

	public static class Sort_Reducer extends Reducer<Text, Text, Text, NullWritable> {

		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			for (Text t : values) {
				context.write(t, NullWritable.get());
			}
		}
	}
}