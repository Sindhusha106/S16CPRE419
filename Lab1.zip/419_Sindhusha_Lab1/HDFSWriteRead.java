
import org.apache.hadoop.conf.*;
import org.apache.hadoop.fs.*;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

public class HDFSWriteRead  {
    
    public static void main ( String [] args ) throws Exception {
        
        // The system configuration
        Configuration conf = new Configuration(); 
        
        // Get an instance of the Filesystem
        FileSystem fs = FileSystem.get(conf);
        
        // address of the byte stored in a long int variable 
        long address = 5000000000L;
        
        // Path to the data set
        String path_name = "/class/s16419x/lab1/bigdata";
        
        Path path = new Path(path_name);
        
        // The Output Data Stream to write into
        FSDataInputStream fsInput = fs.open(path);
        
        // Navigate to the specified address
        fsInput.seek(address);
        
        // Declare a tmp variable of type byte to read the file byte wise 
        byte[] tmp = new byte[1];
        
        // Reading the tmp variable 
		fsInput.read(tmp);
		
		// XOR Result variable 
		byte result = tmp[0];
		
		//initialize counter 
		int count = 1;
			
		while( count<= 999){
			fsInput.read(tmp);
			result ^= tmp[0];
			count++;
		}
		
		System.out.println("Done: " + result);
		
	
        // Close the file and the file system instance
        fsInput.close(); 
        fs.close();
        
    }

}


			
		
