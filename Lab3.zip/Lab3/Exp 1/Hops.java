import java.io.IOException;
import java.util.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class Hops{
	
	public static void main (String[] args) throws Exception {
		
		Configuration conf = new Configuration();

		String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

		String input = "/class/s16419x/lab3/patents.txt";
		String temp = "/scr/dsindhu/lab3/exp1/temp/";  
		String temp1 = "/scr/dsindhu/lab3/exp1/temp1/";
		String output = "/scr/dsindhu/lab3/exp1/output/"; 
		
		int reduce_tasks = 4;  // The number of reduce tasks that will be assigned to the job
		
		// Create job for round 1
		Job job_one = Job.getInstance(conf, "Hops Program Round One");
		
		// Attach the job to this Hops
		job_one.setJarByClass(Hops.class); 
		
		// Specify the number of reduce tasks to run, if not the system decides for itself
		job_one.setNumReduceTasks(reduce_tasks);
		
		// Set the output key-value pairs for Mapper and Reducer
		job_one.setMapOutputKeyClass(Text.class);
		job_one.setMapOutputValueClass(Text.class);
		job_one.setOutputKeyClass(Text.class); 
		job_one.setOutputValueClass(Text.class);
		
		// The class that provides the map method
		job_one.setMapperClass(Map_One.class); 
		
		// The class that provides the reduce method
		job_one.setReducerClass(Reduce_One.class);
		
		// Decides how the input will be split
		// We are using TextInputFormat which splits the data line by line
		// This means each map method receives one line as an input
		job_one.setInputFormatClass(TextInputFormat.class);  
		// Decides the Output Format
		job_one.setOutputFormatClass(TextOutputFormat.class);
		
		// The input HDFS path for this job
		// The path can be a directory containing several files
		// You can add multiple input paths including multiple directories
		FileInputFormat.addInputPath(job_one, new Path(input)); 
		// FileInputFormat.addInputPath(job_one, new Path(another_input_path)); // This is legal
		
		// The output HDFS path for this job
		// The output path must be one and only one
		// This must not be shared with other running jobs in the system
		FileOutputFormat.setOutputPath(job_one, new Path(temp));
		// FileOutputFormat.setOutputPath(job_one, new Path(another_output_path)); // This is not allowed
		
		// Run the job
		job_one.waitForCompletion(true); 
		
	
		
		// Create job for round 2
		Job job_two = Job.getInstance(conf, "Hops Program Round Two");
				
		// Attach the job to this Hops
		job_two.setJarByClass(Hops.class); 
				
		// Specify the number of reduce tasks to run, if not the system decides for itself
		job_two.setNumReduceTasks(reduce_tasks);
				
		// Set the output key-value pairs for Mapper and Reducer
		job_two.setMapOutputKeyClass(Text.class);
		job_two.setMapOutputValueClass(Text.class);
		job_two.setOutputKeyClass(Text.class); 
		job_two.setOutputValueClass(Text.class);
				
		// The class that provides the map method
		job_two.setMapperClass(Map_Two.class); 
				
		// The class that provides the reduce method
		job_two.setReducerClass(Reduce_Two.class);
				
		// Decides how the input will be split
		// We are using TextInputFormat which splits the data line by line
		// This means each map method receives one line as an input
		job_two.setInputFormatClass(TextInputFormat.class);  
		// Decides the Output Format
		job_two.setOutputFormatClass(TextOutputFormat.class);
				
		// The input HDFS path for this job
		// The path can be a directory containing several files
		// You can add multiple input paths including multiple directories
		FileInputFormat.addInputPath(job_two, new Path(temp)); 
		// FileInputFormat.addInputPath(job_one, new Path(another_input_path)); // This is legal
				
		// The output HDFS path for this job
		// The output path must be one and only one
		// This must not be shared with other running jobs in the system
		FileOutputFormat.setOutputPath(job_two, new Path(temp1));
		// FileOutputFormat.setOutputPath(job_one, new Path(another_output_path)); // This is not allowed
				
		// Run the job
		job_two.waitForCompletion(true); 
		
		
		
		
		// Create job for round 2
		Job job_three = Job.getInstance(conf, "Hops Program Round Three");
						
		// Attach the job to this Hops
		job_three.setJarByClass(Hops.class); 
						
		// Specify the number of reduce tasks to run, if not the system decides for itself
		job_three.setNumReduceTasks(reduce_tasks);
						
		// Set the output key-value pairs for Mapper and Reducer
		job_three.setMapOutputKeyClass(Text.class);
		job_three.setMapOutputValueClass(Text.class);
		job_three.setOutputKeyClass(Text.class); 
		job_three.setOutputValueClass(IntWritable.class);
						
		// The class that provides the map method
		job_three.setMapperClass(Map_Three.class); 
						
		// The class that provides the reduce method
		job_three.setReducerClass(Reduce_Three.class);
						
		// Decides how the input will be split
		// We are using TextInputFormat which splits the data line by line
		// This means each map method receives one line as an input
		job_three.setInputFormatClass(TextInputFormat.class);  
		// Decides the Output Format
		job_three.setOutputFormatClass(TextOutputFormat.class);
						
		// The input HDFS path for this job
		// The path can be a directory containing several files
		// You can add multiple input paths including multiple directories
		FileInputFormat.addInputPath(job_three, new Path(temp1)); 
		// FileInputFormat.addInputPath(job_one, new Path(another_input_path)); // This is legal
						
		// The output HDFS path for this job
		// The output path must be one and only one
		// This must not be shared with other running jobs in the system
		FileOutputFormat.setOutputPath(job_three, new Path(output));
		// FileOutputFormat.setOutputPath(job_one, new Path(another_output_path)); // This is not allowed
						
		// Run the job
		job_three.waitForCompletion(true); 
				
				
		
	} // End run
	
	// The Map Class
	// The input to the map method would be a LongWritable (long) key and Text (String) value
	// Notice the class declaration is done with LongWritable key and Text value
	// The TextInputFormat splits the data line by line.
	// The key for TextInputFormat is nothing but the line number and hence can be ignored
	// The value for the TextInputFormat is a line of text from the input
	// The map method can emit data using context.write() method
	// However, to match the class declaration, it must emit Text as key and IntWribale as value
	public static class Map_One extends Mapper<LongWritable, Text, Text, Text>  {
		
		// The map method 
		public void map(LongWritable key, Text value, Context context) 
								throws IOException, InterruptedException  {
	
			  
			// The TextInputFormat splits the data line by line.
			// So each map method receives one line from the input
			String input_line[] = value.toString().split("\\s+");
			String a = input_line[0];
			String b = input_line[1];
			
			context.write(new Text(a), new Text(">"+b));
			context.write(new Text(b), new Text("<"+a));
						
		} // End method "map"
		
	} // End Class Map_One
	
	
	
	// The reduce class
	// The key is Text and must match the datatype of the output key of the map method
	// The value is Text and also must match the datatype of the output value of the map method
	public static class Reduce_One extends Reducer<Text, Text, Text, Text>  {
		
		public void reduce(Text key, Iterable<Text> values, Context context) 
											throws IOException, InterruptedException  {
			
			String list="";
			
			for (Text val : values) {
				context.progress();
				list += val + ",";
			}
			
			// eliminating the final comma 
			list = list.substring(0,list.length()-1);
			context.write(key, new Text(list));
			
		} // End method "reduce" 
		
	} // End Class Reduce_One

	
//////////////////////////////////////////
	
public static class Map_Two extends Mapper<LongWritable, Text, Text, Text>  {
	
	// The map method 
	public void map(LongWritable key, Text value, Context context) 
							throws IOException, InterruptedException  {

		 String line[] = value.toString().split("\\s+");
		 String middle = line[0];
		 String values[] = line[1].split(",");
		 
		// Declare two Hashsets to store the values 
		 HashSet<String> hash_up = new HashSet<String>();
		 HashSet<String> hash_down = new HashSet<String>();		 
		 
		 for(String s: values)
		 {
			if((s.charAt(0)+"").equals("<")){
				hash_up.add(s);
					} else if((s.charAt(0)+"").equals(">")){
				hash_down.add(s);
					}
			else{
				context.write(new Text(middle), new Text(s.substring(0)+"else"));
			}
			}
			 
	//	Set<String> outputhops = new HashSet<String>();
		for(String up:hash_up){
			for(String down:hash_down){
				if(!(middle.equals(down.substring(1)))){
				context.write(new Text(down.substring(1)), new Text(middle));}
				if(!(up.substring(1)).equals(down.substring(1)))                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       {
				context.write(new Text(down.substring(1)), new Text(up.substring(1)+"-"+middle));}
				if(!(middle.equals(up.substring(1)))){
				context.write(new Text(middle), new Text(up.substring(1)));}
				
				}
			
		}
		 
		 					
	} // End method "map"
	
} // End Class Map_One


public static class Reduce_Two extends Reducer<Text, Text, Text, Text>  {
	
	// The reduce method
	// For key, we have an Iterable over all values associated with this key
	// The values come in a sorted fashion.
	public void reduce(Text key, Iterable<Text> values, Context context) 
										throws IOException, InterruptedException  {
		
		String list="";
		
		for (Text val : values) {
			context.progress();
			list += new Text(val) + ",";
			
		}
		
		// eliminating the final comma 
		list = list.substring(0,list.length()-1);
		context.write(key, new Text(list));
		
	} // End method "reduce" 
	
} // End Class Reduce_Two

//////////////////////////////////////////

public static class Map_Three extends Mapper<LongWritable, Text, Text, Text>  {

	// The map method 
	public void map(LongWritable key, Text value, Context context) 
			throws IOException, InterruptedException  {


		String line[] = value.toString().split("\t");
		String middle = line[0];
		String values[] = line[1].split(",");
		String textkey = "key";
		HashSet<String> value_hops = new HashSet<String>();

		for(String s: values)
		{
				String patents[] = s.split("-");
				for(String u:patents)
				{
					value_hops.add(u);					
				}
		}
				context.write(new Text(textkey), new Text(line[0]+"&"+value_hops.size()));
			
	}
}	

public static class Reduce_Three extends Reducer<Text, Text, Text, IntWritable>  {
	
	// The reduce method
	// For key, we have an Iterable over all values associated with this key
	// The values come in a sorted fashion.
	public void reduce(Text key, Iterable<Text> values, Context context) 
										throws IOException, InterruptedException  {
	
		
	HashMap<String,Integer> best = new HashMap<String, Integer>();
	
	for (Text t:values){
		String s = t.toString();
		String split_val[] = s.split("&");
		int val = Integer.parseInt(split_val[1]);
		String patent_no = split_val[0];
		
		if(best.size()<10)
		{
		//Allowing only 10 entries	
			best.put(patent_no, val);
		}
		else{
			
		Map.Entry<String,Integer> min=null;
		for (Map.Entry<String, Integer> t:best.entrySet()){
			if (min == null){
				min = t;
				
			}else{
				if (t.getValue() < min.getValue()){
					min = t;
				}
				
			}
			
		}
		if(val>min.getValue()){
			best.remove(min.getKey());
			best.put(patent_no, val);
		}
		}
			
		
	}
	
		for(Map.Entry<String, Integer> t : best.entrySet()){
			context.write(new Text(t.getKey()), new IntWritable(t.getValue()));
			
		}
	}
	}
}



