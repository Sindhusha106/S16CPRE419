import java.io.IOException;
import java.util.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

public class Triangles{
	
	public static void main (String[] args) throws Exception {
		
		Configuration conf = new Configuration();

		String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
		
		// Change input and output paths accordingly or pass arguments from command line
		String input = "/class/s16419x/lab3/patents.txt";
		String temp = "/scr/dsindhu/lab3/exp2/temp/";  
		String temp1 = "/scr/dsindhu/lab3/exp2/temp1/";
		String output = "/scr/dsindhu/lab3/exp2/output/"; 
		
		int reduce_tasks = 4;  // The number of reduce tasks that will be assigned to the job
		
		// Create job for round 1
		Job job_one = Job.getInstance(conf, "Triangles Program Round One");
		
		// Attach the job to this Hops
		job_one.setJarByClass(Triangles.class); 
		
		// Specify the number of reduce tasks to run, if not the system decides for itself
		job_one.setNumReduceTasks(reduce_tasks);
		
		// Set the output key-value pairs for Mapper and Reducer
		job_one.setMapOutputKeyClass(Text.class);
		job_one.setMapOutputValueClass(Text.class);
		job_one.setOutputKeyClass(Text.class); 
		job_one.setOutputValueClass(Text.class);
		
		// The class that provides the map method
		job_one.setMapperClass(Map_One.class); 
		
		// The class that provides the reduce method
		job_one.setReducerClass(Reduce_One.class);
		
		// Decides how the input will be split
		// We are using TextInputFormat which splits the data line by line
		// This means each map method receives one line as an input
		job_one.setInputFormatClass(TextInputFormat.class);  
		// Decides the Output Format
		job_one.setOutputFormatClass(TextOutputFormat.class);
		
		// The input HDFS path for this job
		// The path can be a directory containing several files
		// You can add multiple input paths including multiple directories
		FileInputFormat.addInputPath(job_one, new Path(input)); 
		// FileInputFormat.addInputPath(job_one, new Path(another_input_path)); // This is legal
		
		// The output HDFS path for this job
		// The output path must be one and only one
		// This must not be shared with other running jobs in the system
		FileOutputFormat.setOutputPath(job_one, new Path(temp));
		// FileOutputFormat.setOutputPath(job_one, new Path(another_output_path)); // This is not allowed
		
		// Run the job
		job_one.waitForCompletion(true); 
		
	//-------------------------------------------------------------------------------------------------------------		
		// Create job for round 2
		Job job_two = Job.getInstance(conf, "Triangles Program Round Two");
				
		// Attach the job to this Hops
		job_two.setJarByClass(Triangles.class); 
				
		// Specify the number of reduce tasks to run, if not the system decides for itself
		job_two.setNumReduceTasks(reduce_tasks);
				
		// Set the output key-value pairs for Mapper and Reducer
		job_two.setMapOutputKeyClass(Text.class);
		job_two.setMapOutputValueClass(Text.class);
		job_two.setOutputKeyClass(Text.class); 
		job_two.setOutputValueClass(Text.class);
				
		// The class that provides the map method
		job_two.setMapperClass(Map_Two.class); 
				
		// The class that provides the reduce method
		job_two.setReducerClass(Reduce_Two.class);
				
		// Decides how the input will be split
		// We are using TextInputFormat which splits the data line by line
		// This means each map method receives one line as an input
		job_two.setInputFormatClass(TextInputFormat.class);  
		// Decides the Output Format
		job_two.setOutputFormatClass(TextOutputFormat.class);
				
		// The input HDFS path for this job
		// The path can be a directory containing several files
		// You can add multiple input paths including multiple directories
		FileInputFormat.addInputPath(job_two, new Path(temp)); 
		// FileInputFormat.addInputPath(job_one, new Path(another_input_path)); // This is legal
				
		// The output HDFS path for this job
		// The output path must be one and only one
		// This must not be shared with other running jobs in the system
		FileOutputFormat.setOutputPath(job_two, new Path(temp1));
		// FileOutputFormat.setOutputPath(job_one, new Path(another_output_path)); // This is not allowed
				
		// Run the job
		job_two.waitForCompletion(true); 
		
	//-------------------------------------------------------------------------------------------------------------
		
		
		// Create job for round 2
		Job job_three = Job.getInstance(conf, "Triangles Program Round Three");
						
		// Attach the job to this Hops
		job_three.setJarByClass(Triangles.class); 
						
		// Specify the number of reduce tasks to run, if not the system decides for itself
		job_three.setNumReduceTasks(reduce_tasks);
						
		// Set the output key-value pairs for Mapper and Reducer
		job_three.setMapOutputKeyClass(Text.class);
		job_three.setMapOutputValueClass(Text.class);
		job_three.setOutputKeyClass(Text.class); 
		job_three.setOutputValueClass(IntWritable.class);
						
		// The class that provides the map method
		job_three.setMapperClass(Map_Three.class); 
						
		// The class that provides the reduce method
		job_three.setReducerClass(Reduce_Three.class);
						
		// Decides how the input will be split
		// We are using TextInputFormat which splits the data line by line
		// This means each map method receives one line as an input
		job_three.setInputFormatClass(TextInputFormat.class);  
		// Decides the Output Format
		job_three.setOutputFormatClass(TextOutputFormat.class);
						
		// The input HDFS path for this job
		// The path can be a directory containing several files
		// You can add multiple input paths including multiple directories
		FileInputFormat.addInputPath(job_three, new Path(temp1)); 
		// FileInputFormat.addInputPath(job_one, new Path(another_input_path)); // This is legal
						
		// The output HDFS path for this job
		// The output path must be one and only one
		// This must not be shared with other running jobs in the system
		FileOutputFormat.setOutputPath(job_three, new Path(output));
		// FileOutputFormat.setOutputPath(job_one, new Path(another_output_path)); // This is not allowed
						
		// Run the job
		job_three.waitForCompletion(true); 
		
				
		
	} // End run
	
	
	
	//---------------------------------------------MapReduce Round 1----------------------------------------------------------------

	public static class Map_One extends Mapper<LongWritable, Text, Text, Text>  {

		public void map(LongWritable key, Text value, Context context) 
								throws IOException, InterruptedException  {
			String line[] = value.toString().split("\\s+");
			String a = line[0];
			String b = line[1];
			
			if (a.compareTo(b) != 0) {
			  context.write(new Text(a), new Text(b));
			  context.write(new Text(b), new Text(a));
			} else {
			  
			}
      
		} 
	}
	
public static class Reduce_One extends Reducer<Text, Text, Text, Text>  {
		
		public void reduce(Text key, Iterable<Text> values, Context context) 
											throws IOException, InterruptedException  {

      String list = "";
      int count = 0;		
			for (Text val : values) {
				list += val + ",";
			  count++;
			}
			
			if (count < 2) {
			  //no triangles are possible
			  //////////// >>>>>>>>>>>>>> write code for triplets 
			} else {
				list = list.substring(0, list.length()-1);
        context.write(key, new Text(list));
			}
			
		} 
		
	} 

//---------------------------------------------MapReduce Round 2----------------------------------------------------------------

public static class Map_Two extends Mapper<LongWritable, Text, Text, Text>  {
	
	private Text yes = new Text("yes");
	
	public void map(LongWritable key, Text value, Context context) 
			throws IOException, InterruptedException  {
	  
	  String input_line[] = value.toString().split("\t");
	  String a = input_line[0];
	  String values[] = input_line[1].split(",");

  Set<String> set_one = new HashSet<String>(values.length);

  for (String b : values) {
    if (a.compareTo(b) < 0) {
    	//send the values with lower number first
    	set_one.add(a+"-"+b);
    } else {
    	set_one.add(b+"-"+a);
    }
  }
  
  for (String x : set_one) {
	  // sending the (a,b)and yes to indicate that there is a relationship
    context.write(new Text(x), new Text(yes));
  }
  
  Set<String> set_two = new HashSet<String>(values.length);
  
  for (int i = 0; i < values.length; i++) {
    for (int j = i+1; j < values.length; j++) {
      if (values[i].compareTo(values[j]) < 0) {
    	  set_two.add(values[i]+"-"+values[j]);
      } else {
    	  set_two.add(values[j]+"-"+values[i]);
      }
    }
  }
  
  for (String s : set_two) {
	  //send the end two points and the key value 
    context.write(new Text(s), new Text(a));
  }
  
	}
}  


public static class Reduce_Two extends Reducer<Text, Text, Text, IntWritable>  {
	
	private IntWritable one = new IntWritable(1);
	private IntWritable two = new IntWritable(2);
	private Text a = new Text("a");
	
	public void reduce(Text key, Iterable<Text> values, Context context) 
			throws IOException, InterruptedException  {
	 Set<String> trips = new HashSet<String>();	
	 Set<String> tris = new HashSet<String>();
	 Set<String> h_set = new HashSet<String>();
	 String pair[] = key.toString().split("-");
	 String a = pair[0];
	 String b = pair[1];
        
    boolean cond = false;
	  for (Text t : values) {
	    String s = t.toString();
	    if (s.equals("yes")) {
	      cond = true;
	    } else {
	      if(a.compareTo(b)<0){
	     trips.add(a+"-"+s+"-"+b);
	      }
	      h_set.add(s);
	    }
	  }
	  
	  if (cond) {
	    for (String c : h_set) {
	      if (a.compareTo(b)<0 && b.compareTo(c)<0) {
	        tris.add(a+"-"+b+"-"+c);
	      }
	     
	    }
	    
	    for (String s : tris) {
	       context.write(new Text("tris"+"&"+s), one);
	    }
	    
	  } else {
	   	  }
	
	for(String s : trips){
		
		context.write(new Text("trips"+"&"+s), one);
	}
	
	} 
	
}  

//---------------------------------------------MapReduce Round 3----------------------------------------------------------------

public static class Map_Three extends Mapper<LongWritable, Text, Text, Text>  {

Text t = new Text("key");

	public void map(LongWritable key, Text value, Context context) 
							throws IOException, InterruptedException  {
	  String input_line[] = value.toString().split("\t");

  context.write(t, new Text(input_line[0]));
	}
} 

public static class Reduce_Three extends Reducer<Text, Text, Text, Text>  {
	
	public void reduce(Text key, Iterable<Text> values, Context context)
										throws IOException, InterruptedException {
		
		
		int triangles = 0; 
		int triplets = 0;
	  
		for (Text t : values) {
			String input_line[] = t.toString().split("&");
			if((input_line[0]).equals("trips")){
	    	 triplets++;
			}else{
	    	 triangles++;
			}
	  }
		// Calculate the GCC value which is between 0 and 1 hence float. 
		//context.write(new IntWritable(triangles), new IntWritable(triplets));
		float gcc_value = (3 *(float)triangles)/(float)triplets;
		
	  context.write(new Text("GCC"), new Text(Float.toString(gcc_value)));
	}
}


}