import java.io.IOException;
import java.util.*;
import java.util.Map.*;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.BagFactory;
import org.apache.pig.data.DataBag;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleFactory;

public class MOVINGAVG extends EvalFunc<DataBag> {
	// construct the required implementation of a bag, tuple
	@Override
	public DataBag exec(Tuple input) throws IOException {
		String ticker = (String)input.get(0); 
		Object values = input.get(1);
		BagFactory myBagFactory = BagFactory.getInstance();
		TupleFactory myTupleFactory = TupleFactory.getInstance();
		DataBag myDataBag = myBagFactory.newDefaultBag();
		
		if (values instanceof DataBag) {
			double moving_avg = 0.0;
			
			Iterator<Tuple> tups = ((DataBag) values).iterator();
			// Tuples starting from 20130801 to 20130930
			TreeMap<Integer,Double> myTreeMap1 = new TreeMap<Integer,Double>();
			// Tuples with date from 20131001 to 20131031
			TreeMap<Integer,Double> myTreeMap2 = new TreeMap<Integer,Double>();
			
			while (tups.hasNext()) {
				Tuple t = tups.next();
				int date = (Integer)t.get(1);
				double price = (Double)t.get(2);
				if (date<=20130930) {
					myTreeMap1.put(date, price);
				}
				else {
					myTreeMap2.put(date, price);
				}
			}
			
			if (myTreeMap1.size() < 20) {
				return null;
			}
			int length = 20 + myTreeMap2.size();
			double[] prices = new double[length];
			for (int i=0; i<20; i++) {
				prices[19-i] = myTreeMap1.pollLastEntry().getValue();
				moving_avg += prices[19-i];
			}
			moving_avg = moving_avg/20;
			
			for (int i=0; i<myTreeMap2.size(); i++) {
				Entry<Integer,Double> e = myTreeMap2.pollFirstEntry();
				int date = e.getKey();
				double pr = e.getValue();
				Tuple t = myTupleFactory.newTuple(4);
				t.set(0, ticker);
				t.set(1, date);
				t.set(2, pr);
				t.set(3,moving_avg);
				myDataBag.add(t);
				moving_avg = (moving_avg*20 - prices[i] + pr) / 20;
				prices[20+i] = pr;			
			}
			
			return myDataBag;					
		}
		
		return null;
	}
	
}
