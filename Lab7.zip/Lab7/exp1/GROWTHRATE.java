import java.io.IOException;
import java.util.*;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.DataBag;
import org.apache.pig.data.Tuple;

public class GROWTHRATE extends EvalFunc<Double> {
	@Override
	public Double exec(Tuple input) throws IOException {
		double growthrate = 0.0;
		Object values = input.get(0);
		if (values instanceof DataBag) {
			DataBag bag = (DataBag) values;
			// if company does not have more than 2 values, it is not there for more an 1 day 
			if (bag.size() < 2) {
				return null;
			}
			else {
				Iterator<Tuple> nextTuple = ((DataBag) values).iterator();
				Tuple myTuple1 = nextTuple.next();
				// find the start date
				int start_date = (Integer)myTuple1.get(1);
				int final_date = start_date;
				
				// get the price of the first tuple
				double start_price = (Double)myTuple1.get(2);
				double final_price = start_price;
				// initialize growthrate to 1
				growthrate = 1.0;
				
				while (nextTuple.hasNext()) {
					// get next tuple
					Tuple t = nextTuple.next();
					// get date 
					int date = (Integer)t.get(1);
					// get the price 
					double pr = (Double)t.get(2);
					
					if (date<start_date) {
						start_date = date;
						start_price = pr;
					}
					if (date>final_date) {
						final_date = date;
						final_price = pr;
					}
				}
				
				growthrate = final_price/start_price;	
				return growthrate;
			}
		}	
		return null;
	}
}
