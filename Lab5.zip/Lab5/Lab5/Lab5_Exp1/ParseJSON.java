
/**
 ***************************************** 
 * CPR E 419x - Lab 5  *******************
 *****************************************
 * Yu Zhang  
 * Any question on this code, post on PIAZZA
 */

import java.io.IOException;
import java.util.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
//import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.util.LineReader;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;

public class ParseJSON {

	public static void main(String[] args) throws Exception {

		Configuration conf = new Configuration();
		
		
		String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
	    if (otherArgs.length != 2) {
	      System.err.println("Usage: ParseJSON <in> <out>");
	      System.exit(2);
	    }

		int reduce_tasks = 4;
		
		String inputDir = otherArgs[0];
		String outputDir = otherArgs[1];
		
		//map input path is the same as the input file
		Path input = new Path(inputDir);
		// map output path gives the sequence file, input file is converted to
		Path temp = new Path(outputDir + "-temp");
		// reduce output path gives the final output file
		Path output = new Path(outputDir+"final-part1");
				
		// Create job
		Job job_one = Job.getInstance(conf, "CPRE 419x JSON parser Round 1");
		job_one.setJarByClass(ParseJSON.class);
		job_one.setNumReduceTasks(reduce_tasks);

		// The datatype of the Output Key and Value
		job_one.setMapOutputKeyClass(Text.class);
		job_one.setMapOutputValueClass(Text.class);
		job_one.setOutputKeyClass(Text.class);
		job_one.setOutputValueClass(Text.class);

		// The class that provides the map method
		job_one.setMapperClass(Map_One.class);
		// The class that provides the reduce method
		job_one.setReducerClass(Reduce_One.class);

		// Decides Input and Output Format
		job_one.setInputFormatClass(MyJSONInputFormat.class);
		job_one.setOutputFormatClass(TextOutputFormat.class);

		// The input HDFS path for this job
		FileInputFormat.addInputPath(job_one, input);

		// The output HDFS path for this job
		FileOutputFormat.setOutputPath(job_one, temp);

		// Run the job
		job_one.waitForCompletion(true);
		
		// Create job
		Job job_two = Job.getInstance(conf, "CPRE 419x JSON parser Round 1");
		job_two.setJarByClass(ParseJSON.class);
		job_two.setNumReduceTasks(reduce_tasks);

		// The datatype of the Output Key and Value
		job_two.setMapOutputKeyClass(Text.class);
		job_two.setMapOutputValueClass(Text.class);
		job_two.setOutputKeyClass(Text.class);
		job_two.setOutputValueClass(Text.class);

		// The class that provides the map method
		job_two.setMapperClass(Map_Two.class);
		// The class that provides the reduce method
		job_two.setReducerClass(Reduce_Two.class);

		// Decides Input and Output Format
		job_two.setInputFormatClass(TextInputFormat.class);  
		job_two.setOutputFormatClass(TextOutputFormat.class);

		// The input HDFS path for this job
		FileInputFormat.addInputPath(job_two, temp);

		// The output HDFS path for this job
		FileOutputFormat.setOutputPath(job_two, output);

		// Run the job
		job_two.waitForCompletion(true);
							

	}

	// The Map Class
	public static class Map_One extends Mapper<LongWritable, Text, Text, Text> {

		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			
			// Get HashTags part.
			JSONParser parser = new JSONParser();
			Set<String> hashtags_table = new HashSet<String>();
			try {
				JSONObject jsonMap = (JSONObject)parser.parse(value.toString());
				JSONObject entities = (JSONObject)jsonMap.get("entities");
				JSONArray hashtags = (JSONArray)entities.get("hashtags");
				for(int i = 0; i < hashtags.size(); i++){
					JSONObject hashObj = (JSONObject)hashtags.get(i);
					String hashtag = hashObj.get("text").toString();
					hashtags_table.add(hashtag);
					//context.write(new Text(hashtag), new Text("one"));
				}
				for(String x:hashtags_table)
				{
					context.write(new Text(x), new Text("one"));
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				context.write(new Text("error"), value);
			}
			
			
		} 
	} 

	// The reduce class
	// In this sample code, we just use the same key and put all the JSON object
	// in one reducer
	public static class Reduce_One extends Reducer<Text, Text, Text, Text> {

		// The reduce method
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			int count = 0;
			// print out all the JSON strings
			for (Text val : values) {
				
				if (val.toString().equals("one")){
					count++;
				}
			}
			
			context.write(key, new Text(count + ""));
		} 
	} 
	
	public static class Map_Two extends Mapper<LongWritable, Text, Text, Text> {

		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			String textkey = "key";
			context.write(new Text(textkey), value);		
			
		} 
	} 

	// The reduce class
	// In this sample code, we just use the same key and put all the JSON object
	// in one reducer
	public static class Reduce_Two extends Reducer<Text, Text, Text, Text> {

		// The reduce method
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			
		HashMap<String,Integer> trends = new HashMap<String, Integer>();
		
		for (Text t:values){
			String s = t.toString();
			String split_val[] = s.split("\t");
			int val = Integer.parseInt(split_val[1]);
			String hashtag = split_val[0];
			
			
			if(trends.size()<10)
			{
				
				trends.put(hashtag, val);
			}else{
				Map.Entry<String, Integer> min = null;	
			for (Map.Entry<String, Integer> x :trends.entrySet()){
				if(min == null)
				{
					min = x;					
				}else{
					if(x.getValue()<min.getValue()){
						min = x;
					}
					
				}
				
			}	
			if(val>min.getValue()){
				trends.remove(min.getKey());
				trends.put(hashtag, val);
				
			}
			}
		}
		for(Map.Entry<String, Integer> t:trends.entrySet()){
			context.write(new Text(t.getKey()), new Text(t.getValue().toString()));
			
		}
		
		} 
	} 

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// My InputFormat
	public static class MyJSONInputFormat extends FileInputFormat<LongWritable, Text> {

		public RecordReader<LongWritable, Text> createRecordReader(InputSplit split, TaskAttemptContext context)
				throws IOException, InterruptedException {
			
			return new MyJSONRecordReader();
			
		}
	}

	// My RecordReader
	public static class MyJSONRecordReader extends RecordReader<LongWritable, Text> {

		private long start;
		private long end;
		private long pos;
		private LineReader in;
		private int maxLineLength;

		private LongWritable key = new LongWritable();
		private Text value = new Text();

		private boolean firstflag = true;

		public void close() throws IOException {
			if (in != null) {
				in.close();
			}
		}

		public LongWritable getCurrentKey() throws IOException, InterruptedException {
			return key;
		}

		public Text getCurrentValue() throws IOException, InterruptedException {
			return value;
		}

		public float getProgress() throws IOException, InterruptedException {
			if (start == end) {
				return 0.0f;
			} else {
				return Math.min(1.0f, (pos - start) / (float) (end - start));
			}
		}

		public void initialize(InputSplit inputSplit, TaskAttemptContext context)
				throws IOException, InterruptedException {
			// This InputSplit is a FileInputSplit
			FileSplit split = (FileSplit) inputSplit;
			// Retrieve configuration, and Max allowed bytes for a single record
			Configuration job = context.getConfiguration();
			this.maxLineLength = job.getInt("mapred.linerecordreader.maxlength", Integer.MAX_VALUE);

			// Get the start and end position of this split
			start = split.getStart();
			end = start + split.getLength();

			// Retrieve file containing split
			final Path file = split.getPath();
			FileSystem fs = file.getFileSystem(job);
			// Retrieve the InputStream of the split
			FSDataInputStream fileIn = fs.open(split.getPath());

			in = new LineReader(fileIn, job);
			Text line = new Text();

			// Find the starting point of a JSON object
			// Use " {" as the criteria, flag is true when start is found
			// pos is the actual start
			pos = start;
			int offset;
			boolean flag = false;
			while (flag == false) {
				line.clear();
				offset = in.readLine(line);
				String str = line.toString();
				if (str.equals(" {")) {
					flag = true;
				} else {
					pos += offset;
				}
			}
		}

		public boolean nextKeyValue() throws IOException, InterruptedException {

			// Current offset is the key
			key.set(pos);

			// newSize is the size of each line that we read
			int newSize = 0;
			Text line = new Text();
			String jsonObj = "";
			// 1 represents "{", -1 represents "}"
			int brace_count = 0;

			if (firstflag == true) {
				jsonObj = " {";
				brace_count = 1;
				firstflag = false;
			}

			while (pos < end) {
				line.clear();
				// Read a new line and store its content to "line"
				newSize = in.readLine(line, maxLineLength,
						Math.max((int) Math.min(Integer.MAX_VALUE, end - pos), maxLineLength));
						
				String str = line.toString();
				// String trimStr = str.replaceAll("\\s+","");
				String trimStr = str.trim();

				// overlook the "][" between two jSON objects
				if (trimStr.equals("][")) {
					continue;
				}

				if (trimStr.startsWith("}")) {
					brace_count--;
				} else if (trimStr.endsWith("{")) {
					brace_count++;
				}

				jsonObj += str;
				pos += newSize;

				// find a JSON object
				if (trimStr.startsWith("}") && brace_count == 0) {
					// remove the characters after the last "}"
					int last = jsonObj.lastIndexOf("}");
					value.set(jsonObj.substring(0, last + 1));
					return true;
				}
			}

			return false;
		}
	}
}