
import java.util.Arrays;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.PairFunction;

import scala.Tuple2;

public class Firewall {

	private final static int numOfReducers = 4;

	@SuppressWarnings("serial")
	public static void main(String[] args) throws Exception {

		if (args.length != 3) {
			System.err.println("Usage: Firewall <input1> <input2> <output>");
			System.exit(1);
		}

		SparkConf sparkConf = new SparkConf().setAppName("Firewall");
		JavaSparkContext context = new JavaSparkContext(sparkConf);
		JavaRDD<String> lines = context.textFile(args[0]);
		// map on ip_trace
		JavaPairRDD<String,String> ip_trace = lines.mapToPair(new PairFunction<String, String, String>() {
			@Override
			public Tuple2<String, String> call(String s) throws Exception {
				String[] tokens = s.split(" ");
				String time = tokens[0];
				String con_id = tokens[1];
				String sourceid = tokens[2];
				String arrow = tokens[3];
				String destid = tokens[4];
				String protocol = tokens[5];
				String data = tokens[6];
				
				String key = con_id;
				String value = time+","+con_id+","+sourceid+","+destid;
				return new Tuple2<String, String>(key, value);
			}
		}).cache();
		// map on raw_block
		JavaRDD<String> blocked = context.textFile(args[1]);
		JavaPairRDD<String,String> raw_block = blocked.mapToPair(new PairFunction<String, String, String>() {
					@Override
					public Tuple2<String, String> call(String s) throws Exception {
						String[] tokens = s.split(" ");
						String connection = tokens[0];
						String action = tokens[1];
						
						String key = connection;
						String value = action;
						return new Tuple2<String, String>(key, value);
						}
				}).cache();
		
		JavaPairRDD<String, String> filterAction = raw_block.filter(new Function<Tuple2<String, String>, Boolean>() {
			@Override
			public Boolean call(Tuple2<String, String> tuple) throws Exception {
				String value = tuple._2;
				if (value.equals("Blocked")) {
					return true;
				}
				return false;
			}
		});
				
		JavaPairRDD<String, Tuple2<String, String>> joinedData = ip_trace.join(filterAction, numOfReducers);

		JavaPairRDD<String, String> value_data = joinedData.mapValues(new Function<Tuple2<String, String>, String>() {
			@Override
			public String call(Tuple2<String, String> tuple) throws Exception {
				String tuples[] = tuple._1().split(",");
				String time = tuples[0];
				String connection = tuples[1];
				String source = tuples[2];
				String destination = tuples[3];
				String action = tuple._2();
				
				return time+" "+connection+" "+source+" "+destination+" "+action;
			}
		});	
		
		JavaRDD<String> final_data = value_data.values();
		
		final_data.saveAsTextFile(args[2]);
		context.stop();
		context.close();
	}
}